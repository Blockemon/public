# <img src="https://i.imgur.com/afYlNbB.png"  width="32px" height="32px"> About (1.20 no-replace)
Requested by keksuccino

This version is not replacing default font. You will not see monospaced font anywhere in-game unless you state that you want monospaced font:
`/tellraw @s {"text":"This is using default font"}` will output a string with default font
`/tellraw @s {"text":"This is using monospaced font","font":"mono"}` will output a string with monospaced font

The difference is that we specified font by adding `"font":"mono"` to JSON raw text


### License
This project uses [CC-BY 4.0](https://www.tldrlegal.com/license/creative-commons-attribution-4-0-international-cc-by-4)</br>
[![CC-BY 4.0](https://i.imgur.com/XBu1mBH.png)](https://www.tldrlegal.com/license/creative-commons-attribution-4-0-international-cc-by-4)
