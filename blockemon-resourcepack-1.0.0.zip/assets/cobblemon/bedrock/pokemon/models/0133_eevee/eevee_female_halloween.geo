{
	"format_version": "1.12.0",
	"minecraft:geometry": [
		{
			"description": {
				"identifier": "geometry.eevee_female_halloween",
				"texture_width": 128,
				"texture_height": 128,
				"visible_bounds_width": 3,
				"visible_bounds_height": 2.5,
				"visible_bounds_offset": [0, 0.75, 0]
			},
			"bones": [
				{
					"name": "eevee",
					"pivot": [0, 0, 0]
				},
				{
					"name": "body",
					"parent": "eevee",
					"pivot": [0, 7.75, 0]
				},
				{
					"name": "torso",
					"parent": "body",
					"pivot": [0, 7.75, 0],
					"cubes": [
						{"origin": [-3.5, 4.75, -6], "size": [7, 6, 12], "uv": [0, 14]},
						{"origin": [-5, 5.5, -8.75], "size": [10, 6, 9], "pivot": [0.5, 8.5, -4.25], "rotation": [30, 0, 0], "uv": [42, 34]}
					]
				},
				{
					"name": "head",
					"parent": "torso",
					"pivot": [0, 10.25, -5],
					"cubes": [
						{"origin": [-4, 8.75, -9.25], "size": [8, 8, 7], "uv": [0, 46]},
						{"origin": [-3, 9.5, -10], "size": [6, 2, 1], "uv": [20, 32]},
						{"origin": [-3, 16.5, -6.25], "size": [6, 2, 0], "pivot": [0, 17.5, -6], "rotation": [-15, 0, 0], "uv": [0, 32]},
						{"origin": [-0.5, 10.51, -10.01], "size": [1, 1, 0], "uv": [0, 24]}
					]
				},
				{
					"name": "hat",
					"parent": "head",
					"pivot": [0, 15.75, -6.25],
					"rotation": [-12.5, 0, 0],
					"cubes": [
						{"origin": [-2, 17.75, -6.75], "size": [4, 6, 8], "inflate": 0.01, "uv": [4, 32]},
						{"origin": [-4, 15.75, -9.75], "size": [8, 6, 8], "inflate": 0.01, "uv": [16, 0]},
						{"origin": [-4, 15.75, -12.75], "size": [8, 0, 14], "uv": [-14, 0]},
						{"origin": [-9, 15.75, -12.75], "size": [5, 0, 14], "pivot": [-4, 15.75, -6.25], "rotation": [0, 0, -10], "uv": [24, 14], "mirror": true},
						{"origin": [4, 15.75, -12.75], "size": [5, 0, 14], "pivot": [4, 15.75, -6.25], "rotation": [0, 0, -10], "uv": [24, 14]}
					]
				},
				{
					"name": "mouth",
					"parent": "head",
					"pivot": [0, 0.05, -0.75]
				},
				{
					"name": "mouth_closed",
					"parent": "mouth",
					"pivot": [0, 10.01, -10.01],
					"cubes": [
						{"origin": [-1, 9.51, -10.01], "size": [2, 1, 0], "uv": [0, 23]}
					]
				},
				{
					"name": "mouth_open",
					"parent": "mouth",
					"pivot": [0, 10.01, -9.91],
					"cubes": [
						{"origin": [-1, 9.51, -9.91], "size": [2, 1, 0], "uv": [0, 22]}
					]
				},
				{
					"name": "eyes",
					"parent": "head",
					"pivot": [0, 13, -9.3]
				},
				{
					"name": "eye_right",
					"parent": "eyes",
					"pivot": [-2.5, 13, -9.26],
					"cubes": [
						{"origin": [-3.5, 11.5, -9.26], "size": [2, 3, 0], "uv": [44, 0]}
					]
				},
				{
					"name": "eyelid_right",
					"parent": "eye_right",
					"pivot": [-2.5, 13, -8.66],
					"cubes": [
						{"origin": [-3.5, 11.5, -9.16], "size": [2, 3, 1], "inflate": 0.01, "uv": [17, 0]}
					]
				},
				{
					"name": "eye_left",
					"parent": "eyes",
					"pivot": [2.5, 13, -9.26],
					"cubes": [
						{"origin": [1.5, 11.5, -9.26], "size": [2, 3, 0], "uv": [44, 0], "mirror": true}
					]
				},
				{
					"name": "eyelid_left",
					"parent": "eye_left",
					"pivot": [2.5, 13, -8.66],
					"cubes": [
						{"origin": [1.5, 11.5, -9.16], "size": [2, 3, 1], "inflate": 0.01, "uv": [17, 0], "mirror": true}
					]
				},
				{
					"name": "ear_right",
					"parent": "head",
					"pivot": [-3.25, 16.75, -5.5],
					"rotation": [-10, 15, -32.5],
					"cubes": [
						{"origin": [-5.75, 15.75, -5.5], "size": [4, 8, 0], "uv": [0, 14], "mirror": true}
					]
				},
				{
					"name": "ear_left",
					"parent": "head",
					"pivot": [3.25, 16.75, -5.5],
					"rotation": [-10, -15, 32.5],
					"cubes": [
						{"origin": [1.75, 15.75, -5.5], "size": [4, 8, 0], "uv": [0, 14]}
					]
				},
				{
					"name": "tail",
					"parent": "torso",
					"pivot": [0, 9.25, 6],
					"rotation": [45, 0, 0],
					"cubes": [
						{"origin": [-4, 6.25, 5], "size": [8, 7, 10], "uv": [48, 0]}
					]
				},
				{
					"name": "leg_front_right",
					"parent": "body",
					"pivot": [-2.5, 7, -3.75],
					"rotation": [2.5, 0, 0],
					"cubes": [
						{"origin": [-4, 3.5, -5.25], "size": [3, 5, 3], "inflate": 0.01, "uv": [26, 14], "mirror": true}
					]
				},
				{
					"name": "leg_front_right2",
					"parent": "leg_front_right",
					"pivot": [-2.5, 3.5, -2.25],
					"rotation": [-22.5, 0, 0],
					"cubes": [
						{"origin": [-4, 0.5, -5.25], "size": [3, 3, 3], "uv": [25, 45], "mirror": true}
					]
				},
				{
					"name": "leg_front_right3",
					"parent": "leg_front_right2",
					"pivot": [-2.5, 1, -3.75],
					"rotation": [20, 0, 0],
					"cubes": [
						{"origin": [-4, -0.75, -5.5], "size": [3, 2, 3], "inflate": 0.01, "uv": [0, 34], "mirror": true}
					]
				},
				{
					"name": "leg_front_left",
					"parent": "body",
					"pivot": [2.5, 7, -3.75],
					"rotation": [2.5, 0, 0],
					"cubes": [
						{"origin": [1, 3.5, -5.25], "size": [3, 5, 3], "inflate": 0.01, "uv": [26, 14]}
					]
				},
				{
					"name": "leg_front_left2",
					"parent": "leg_front_left",
					"pivot": [2.5, 3.5, -2.25],
					"rotation": [-22.5, 0, 0],
					"cubes": [
						{"origin": [1, 0.5, -5.25], "size": [3, 3, 3], "uv": [25, 45]}
					]
				},
				{
					"name": "leg_front_left3",
					"parent": "leg_front_left2",
					"pivot": [2.5, 1, -3.75],
					"rotation": [20, 0, 0],
					"cubes": [
						{"origin": [1, -0.75, -5.5], "size": [3, 2, 3], "inflate": 0.01, "uv": [0, 34]}
					]
				},
				{
					"name": "leg_back_right",
					"parent": "body",
					"pivot": [-2.5, 7.75, 3.5],
					"rotation": [10, 0, 0],
					"cubes": [
						{"origin": [-4, 4.25, 1.5], "size": [3, 5, 4], "inflate": 0.01, "uv": [28, 36], "mirror": true}
					]
				},
				{
					"name": "leg_back_right2",
					"parent": "leg_back_right",
					"pivot": [-2.5, 4.25, 5],
					"rotation": [-22.5, 0, 0],
					"cubes": [
						{"origin": [-4, 0.5, 3], "size": [3, 4, 3], "uv": [35, 29], "mirror": true}
					]
				},
				{
					"name": "leg_back_right3",
					"parent": "leg_back_right2",
					"pivot": [-2.5, 1, 4.5],
					"rotation": [12.5, 0, 0],
					"cubes": [
						{"origin": [-4, -0.5, 2.75], "size": [3, 2, 3], "inflate": 0.01, "uv": [20, 35], "mirror": true}
					]
				},
				{
					"name": "leg_back_left",
					"parent": "body",
					"pivot": [2.5, 7.75, 3.5],
					"rotation": [10, 0, 0],
					"cubes": [
						{"origin": [1, 4.25, 1.5], "size": [3, 5, 4], "inflate": 0.01, "uv": [28, 36]}
					]
				},
				{
					"name": "leg_back_left2",
					"parent": "leg_back_left",
					"pivot": [2.5, 4.25, 5],
					"rotation": [-22.5, 0, 0],
					"cubes": [
						{"origin": [1, 0.5, 3], "size": [3, 4, 3], "uv": [35, 29]}
					]
				},
				{
					"name": "leg_back_left3",
					"parent": "leg_back_left2",
					"pivot": [2.5, 1, 4.5],
					"rotation": [12.5, 0, 0],
					"cubes": [
						{"origin": [1, -0.5, 2.75], "size": [3, 2, 3], "inflate": 0.01, "uv": [20, 35]}
					]
				}
			]
		}
	]
}