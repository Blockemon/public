{
	"format_version": "1.12.0",
	"minecraft:geometry": [
		{
			"description": {
				"identifier": "geometry.pikachu_male_halloween",
				"texture_width": 64,
				"texture_height": 64,
				"visible_bounds_width": 4,
				"visible_bounds_height": 4,
				"visible_bounds_offset": [0, 1, 0]
			},
			"bones": [
				{
					"name": "pikachu",
					"pivot": [0, 0, 0]
				},
				{
					"name": "body",
					"parent": "pikachu",
					"pivot": [0, 8, 0.5]
				},
				{
					"name": "torso",
					"parent": "body",
					"pivot": [0, 5.25, 0.5],
					"cubes": [
						{"origin": [-5, 1.75, -3.5], "size": [10, 8, 8], "uv": [28, 48]},
						{"origin": [-4.5, 9.75, -3], "size": [9, 2, 7], "uv": [32, 0]}
					]
				},
				{
					"name": "head",
					"parent": "torso",
					"pivot": [0, 12.25, 0.25],
					"cubes": [
						{"origin": [-4.5, 11.25, -3.75], "size": [9, 8, 8], "inflate": 0.01, "uv": [0, 1]},
						{"origin": [-0.5, 13.33, -4.53], "size": [1, 1, 1], "pivot": [0, 13.7, -3.5], "rotation": [12.5, 0, 0], "uv": [27, 0]},
						{"origin": [-4.5, 11.3, -4.5], "size": [9, 3, 2], "inflate": 0.02, "pivot": [-0.5, 13.7, -3.5], "rotation": [12.5, 0, 0], "uv": [42, 37]}
					]
				},
				{
					"name": "mouth_closed",
					"parent": "head",
					"pivot": [0, 12.7, -3.5],
					"cubes": [
						{"origin": [-1.5, 11.8, -4.53], "size": [3, 1, 0], "inflate": 0.01, "pivot": [0, 13.7, -3.5], "rotation": [12.5, 0, 0], "uv": [27, 4]},
						{"origin": [-0.5, 12.05, -4.53], "size": [1, 1, 0], "inflate": 0.01, "pivot": [0, 13.7, -3.5], "rotation": [12.5, 0, 0], "uv": [28, 6]},
						{"origin": [-2, 12.3, -4.53], "size": [4, 1, 0], "pivot": [0, 13.7, -3.5], "rotation": [12.5, 0, 0], "uv": [26, 3]}
					]
				},
				{
					"name": "mouth_open",
					"parent": "head",
					"pivot": [0, 12.7, -3.5],
					"cubes": [
						{"origin": [-1.5, 11.55, -4.33], "size": [3, 1, 0], "inflate": 0.01, "pivot": [0, 13.7, -3.3], "rotation": [12.5, 0, 0], "uv": [33, 0]},
						{"origin": [-1, 12.05, -4.33], "size": [2, 1, 0], "inflate": 0.01, "pivot": [0, 13.7, -3.3], "rotation": [12.5, 0, 0], "uv": [34, 0]}
					]
				},
				{
					"name": "eyes",
					"parent": "head",
					"pivot": [0, 16, -3.825]
				},
				{
					"name": "eye_right",
					"parent": "eyes",
					"pivot": [-3, 15.5, -3.825],
					"cubes": [
						{"origin": [-4, 14.5, -3.77], "size": [2, 2, 0], "pivot": [-3, 15.5, -3.77], "rotation": [0, 0, 3], "uv": [0, 0]}
					]
				},
				{
					"name": "eyelid_right",
					"parent": "eye_right",
					"pivot": [-3, 15.5, -3.67],
					"cubes": [
						{"origin": [-4, 14.5, -3.67], "size": [2, 2, 0], "inflate": 0.01, "pivot": [-3, 15.5, -3.67], "rotation": [0, 0, 3], "uv": [0, 4]}
					]
				},
				{
					"name": "ear_right",
					"parent": "head",
					"pivot": [-3.65, 18, 0.425],
					"cubes": [
						{"origin": [-5, 17.5, 0.35], "size": [3, 10, 0], "pivot": [-3.65, 18, 0.425], "rotation": [-15, 30, -35], "uv": [36, 21], "mirror": true}
					]
				},
				{
					"name": "arm_right",
					"parent": "torso",
					"pivot": [-4.5, 10.5, -0.5],
					"cubes": [
						{"origin": [-10.5, 9, -2], "size": [6, 3, 3], "uv": [28, 42], "mirror": true}
					]
				},
				{
					"name": "arm_left",
					"parent": "torso",
					"pivot": [4.5, 10.5, -0.5],
					"cubes": [
						{"origin": [4.5, 9, -2], "size": [6, 3, 3], "uv": [46, 42]}
					]
				},
				{
					"name": "tail",
					"parent": "torso",
					"pivot": [0, 2.75, 3.5],
					"cubes": [
						{"origin": [0, 1.75, 3], "size": [0, 9, 10], "uv": [1, 8]},
						{"origin": [0, 10.74, 6], "size": [0, 7, 13], "uv": [1, 15]}
					]
				},
				{
					"name": "leg_right",
					"parent": "body",
					"pivot": [-4, 5.25, 0.5],
					"cubes": [
						{"origin": [-6, 1.5, -2.5], "size": [4, 6, 6], "pivot": [-4, 4.5, 0], "rotation": [-10, 0, 0], "uv": [44, 21]}
					]
				},
				{
					"name": "foot_right",
					"parent": "leg_right",
					"pivot": [-3.75, 2, 0.75],
					"cubes": [
						{"origin": [-4.75, 1, -0.75], "size": [2, 2, 3], "uv": [10, 59]},
						{"origin": [-5.25, 0, -1.5], "size": [3, 1, 4], "uv": [10, 53], "mirror": true}
					]
				},
				{
					"name": "toes_right",
					"parent": "foot_right",
					"pivot": [-3.75, 0, -1.5],
					"cubes": [
						{"origin": [-5.25, 0, -2.5], "size": [3, 1, 1], "uv": [17, 58], "mirror": true}
					]
				},
				{
					"name": "leg_left",
					"parent": "body",
					"pivot": [4, 5.25, 0.5],
					"cubes": [
						{"origin": [2, 1.5, -2.5], "size": [4, 6, 6], "pivot": [4, 4.5, 0], "rotation": [-10, 0, 0], "uv": [44, 9], "mirror": true}
					]
				},
				{
					"name": "foot_left",
					"parent": "leg_left",
					"pivot": [3.75, 2, 0.75],
					"cubes": [
						{"origin": [2.75, 1, -0.75], "size": [2, 2, 3], "uv": [0, 59], "mirror": true},
						{"origin": [2.25, 0, -1.5], "size": [3, 1, 4], "uv": [0, 54]}
					]
				},
				{
					"name": "toes_left",
					"parent": "foot_left",
					"pivot": [3.75, 0, -1.5],
					"cubes": [
						{"origin": [2.25, 0, -2.5], "size": [3, 1, 1], "uv": [17, 60]}
					]
				}
			]
		}
	]
}